<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class ReferencesJobsTwosTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

    }
}
