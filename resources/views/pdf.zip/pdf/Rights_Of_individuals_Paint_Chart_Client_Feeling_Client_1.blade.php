
        <!DOCTYPE html>
        <html lang="es">
            <head>
                <meta charset="utf-8">
                <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
                <meta name="viewport" content="width=device-width, initial-scale=1">
                
                <title>Rights Of individuals Paint Chart Client Feeling Client 1</title>
            </head>
            <body style="margin-top: -25px !important;">
        <p style="text-align: center;"><span style="font-size: 8pt;">RIGHTS OF INDIVIDUALS WITH DEVELOPMENTAL DISABILITIES</span></p>
<p style="text-align: center;"><span style="font-size: 8pt;">Derechos de personas discapacitadas</span></p>
<p style="text-align: center;"><span style="font-size: 8pt;">Each person living in or receiving services in this facility has the following right</span></p>
<p style="text-align: center;"><span style="font-size: 8pt;">Toda persona viviendo o recibiendo servicios en este lugar tiene los siguientes derechos</span></p>
<table style="height: 2344px; width: 588px; margin-left: auto; margin-right: auto;" width="839">
<tbody>
<tr style="height: 114px;">
<td style="width: 29.875px; height: 114px;">
<p>&nbsp;</p>
</td>
<td style="width: 256.953125px; height: 114px;">
<p><span style="font-size: 8pt;">You have the right to wear your own clothes. You should be able to pick the clothes you wear</span></p>
<p><span style="font-size: 8pt;">Tienes el derecho de usar tu propia ropa. Tu podr&aacute;s escoger la ropa que quieres usar.</span></p>
</td>
<td style="width: 35.75px; height: 114px;">
<p>&nbsp;</p>
</td>
<td style="width: 237.4375px; height: 114px;">
<p><span style="font-size: 8pt;">You have the right to keep and spend own money on the things thar you want and to keep and use your own things.</span></p>
<p><span style="font-size: 8pt;">Tienes el derecho de tener y gastar tu dinero en cosas que quieras tener y usar tus propias cosas.</span></p>
</td>
</tr>
<tr style="height: 160px;">
<td style="width: 29.875px; height: 160px;">
<p>&nbsp;</p>
</td>
<td style="width: 256.953125px; height: 160px;">
<p><span style="font-size: 8pt;">You have the right to keep your own things in a private place that you can get into when you want.</span></p>
<p><span style="font-size: 8pt;">Tienes el derecho de tener tus cosas en un lugar privado para usarlas cuando quieras.</span></p>
<p>&nbsp;</p>
</td>
<td style="width: 35.75px; height: 160px;">
<p>&nbsp;</p>
</td>
<td style="width: 237.4375px; height: 160px;">
<p><span style="font-size: 8pt;">You have the right to be treated well with respect.</span></p>
<p><span style="font-size: 8pt;">Tienes el derecho de un trato justo y respetuoso.</span></p>
</td>
</tr>
<tr style="height: 154px;">
<td style="width: 29.875px; height: 154px;">
<p>&nbsp;</p>
</td>
<td style="width: 256.953125px; height: 154px;">
<p><span style="font-size: 8pt;">You have the right to see your friends, family, girlfriends or boyfriends every day.</span></p>
<p><span style="font-size: 8pt;">Tienes el derecho de ver a tus amigos, familia, novio(a) todos los d&iacute;as.</span></p>
</td>
<td style="width: 35.75px; height: 154px;">
<p>&nbsp;</p>
</td>
<td style="width: 237.4375px; height: 154px;">
<p><span style="font-size: 8pt;">You have the right to be treated well with respect.</span></p>
<p><span style="font-size: 8pt;">Tienes el derecho de un trato justo y respetuoso.</span></p>
</td>
</tr>
<tr style="height: 193px;">
<td style="width: 29.875px; height: 193px;">
<p>&nbsp;</p>
</td>
<td style="width: 256.953125px; height: 193px;">
<p><span style="font-size: 8pt;">You have the right to use the telephone privately to make or get calls.</span></p>
<p><span style="font-size: 8pt;">Tienes el derecho de usar el tel&eacute;fono para hacer o recibir llamadas en privado.</span></p>
</td>
<td style="width: 35.75px; height: 193px;">
<p>&nbsp;</p>
</td>
<td style="width: 237.4375px; height: 193px;">
<p><span style="font-size: 8pt;">You have the right to spend alone or alone with a friend.</span></p>
<p><span style="font-size: 8pt;">Tienes el derecho de estar solo o con un amigo.</span></p>
</td>
</tr>
<tr style="height: 281px;">
<td style="width: 29.875px; height: 281px;">
<p>&nbsp;</p>
</td>
<td style="width: 256.953125px; height: 281px;">
<p><span style="font-size: 8pt;">You have the right to have paper, stamps and envelopes for writing letters.</span></p>
<p><span style="font-size: 8pt;">You have the right to email and get letters that are not opened.</span></p>
<p><span style="font-size: 8pt;">Tienes el derecho de tener papel, estampillas y sobres para escribir cartas.</span></p>
<p><span style="font-size: 8pt;">Tienes el derecho de mandar y recibir correspondencia sin que este haya sido abierta.</span></p>
</td>
<td style="width: 35.75px; height: 281px;">
<p>&nbsp;</p>
</td>
<td style="width: 237.4375px; height: 281px;">
<p><span style="font-size: 8pt;">You have the right to go school.</span></p>
<p><span style="font-size: 8pt;">Tienes el derecho de asistir a la escuela.</span></p>
</td>
</tr>
<tr style="height: 133px;">
<td style="width: 29.875px; height: 133px;">
<p>&nbsp;</p>
</td>
<td style="width: 256.953125px; height: 133px;">
<p><span style="font-size: 8pt;">You have the right to say &ldquo;NO&rdquo; to electric shock therapy.</span></p>
<p><span style="font-size: 8pt;">Tienes el derecho de decir No a la terapia de descarga el&eacute;ctrica.</span></p>
</td>
<td style="width: 35.75px; height: 133px;">
<p>&nbsp;</p>
</td>
<td style="width: 237.4375px; height: 133px;">
<p><span style="font-size: 8pt;">You have the right to see a doctor as soon as you need to.</span></p>
<p><span style="font-size: 8pt;">Tienes el derecho de ver a un doctor inmediatamente que lo necesites.</span></p>
</td>
</tr>
<tr style="height: 306px;">
<td style="width: 29.875px; height: 306px;">
<p>&nbsp;</p>
</td>
<td style="width: 256.953125px; height: 306px;">
<p><span style="font-size: 8pt;">You have the right say &ldquo;NO&rdquo; too anybody trying to change the way you act by hurting you, scaring you or upsetting you.</span></p>
<p><span style="font-size: 8pt;">Tienes el derecho de decir no a cualquier persona que trate de cambiar tu manera de ser, lastim&aacute;ndote, asust&aacute;ndote o caus&aacute;ndote un disgusto.</span></p>
</td>
<td style="width: 35.75px; height: 306px;">
<p>&nbsp;</p>
</td>
<td style="width: 237.4375px; height: 306px;">
<p><span style="font-size: 8pt;">You have the right to be involved in a religion if you can&rsquo;t to be.</span></p>
<p><span style="font-size: 8pt;">Tienes el derecho de participar en la religi&oacute;n que tu quieras.</span></p>
</td>
</tr>
<tr style="height: 205px;">
<td style="width: 29.875px; height: 205px;">
<p>&nbsp;</p>
</td>
<td style="width: 256.953125px; height: 205px;">
<p><span style="font-size: 8pt;">You have the right to say &ldquo;NO&rdquo; to brain surgery that people want to do because of the way you act.</span></p>
<p><span style="font-size: 8pt;">Tienes el derecho de decir no a una operaci&oacute;n del cerebro tan solo porque la gente quiere que cambies tu forma de actuar.</span></p>
</td>
<td style="width: 35.75px; height: 205px;">
<p>&nbsp;</p>
</td>
<td style="width: 237.4375px; height: 205px;">
<p><span style="font-size: 8pt;">You have the right to meet people and take part in your community activities.</span></p>
<p><span style="font-size: 8pt;">Tienes el derecho de conocer a otras personas y a tomar parte en las actividades de la comunidad.</span></p>
</td>
</tr>
<tr style="height: 181px;">
<td style="width: 29.875px; height: 181px;">
<p>&nbsp;</p>
</td>
<td style="width: 256.953125px; height: 181px;">
<p><span style="font-size: 8pt;">You have the right to say &ldquo;NO&rdquo; to brain surgery that people want to do because of the way you act.</span></p>
<p><span style="font-size: 8pt;">Tienes el derecho de decir no a una operaci&oacute;n del cerebro tan solo porque la gente quiere que cambies tu forma de actuar.</span></p>
</td>
<td style="width: 35.75px; height: 181px;">
<p>&nbsp;</p>
</td>
<td style="width: 237.4375px; height: 181px;">
<p><span style="font-size: 8pt;">You have the right to exercise and have fun</span></p>
<p><span style="font-size: 8pt;">Tienes derecho de disfrutar y hacer ejercicio.</span></p>
</td>
</tr>
<tr style="height: 183px;">
<td style="width: 29.875px; height: 183px;">
<p>&nbsp;</p>
</td>
<td style="width: 256.953125px; height: 183px;">
<p><span style="font-size: 8pt;">You have the right to choose how you want to spend your free time and who you spend it with.</span></p>
<p><span style="font-size: 8pt;">Tienes el derecho de escoger como pasar tu tiempo libre y con quien.</span></p>
</td>
<td style="width: 35.75px; height: 183px;">
<p>&nbsp;</p>
</td>
<td style="width: 237.4375px; height: 183px;">
<p><span style="font-size: 8pt;">You have the right to say &ldquo;NO&rdquo; to things that will put you in danger.</span></p>
<p><span style="font-size: 8pt;">Tienes el derecho de decir no a las cosas que pudieran ponerte en peligro.</span></p>
</td>
</tr>
<tr style="height: 207px;">
<td style="width: 29.875px; height: 207px;">
<p>&nbsp;</p>
</td>
<td style="width: 256.953125px; height: 207px;">
<p><span style="font-size: 8pt;">You have the right to services that help you live, work and play in the most normal possible.</span></p>
<p><span style="font-size: 8pt;">Tienes el derecho de recibir servicios que te ayuden a mejorar tu vida, a trabajar y jugar de la manera mas normal posible.</span></p>
</td>
<td style="width: 35.75px; height: 207px;">
<p>&nbsp;</p>
</td>
<td style="width: 237.4375px; height: 207px;">
<p><span style="font-size: 8pt;">You have the right to make choice about where you live, who you live with, the way you spend your time and who you spend your time with.</span></p>
<p><span style="font-size: 8pt;">Tienes el derecho de escoger en donde vivir, con quien vivir, la manera de como y con quien usar tu tiempo.</span></p>
</td>
</tr>
<tr style="height: 227px;">
<td style="width: 29.875px; height: 227px;">
<p>&nbsp;</p>
</td>
<td style="width: 256.953125px; height: 227px;">
<p><span style="font-size: 8pt;">You have the right to say &ldquo;NO&rdquo; to drugs, being tied or held down or being forced to be alone unless it is necessary to protect you or someone else.</span></p>
<p><span style="font-size: 8pt;">Tienes el derecho de decir &ldquo;NO&rdquo; a las drogas de no se atado o de mantenerte separado al menos que sea necesario para protegerte o proteger a otras personas.</span></p>
<p>&nbsp;</p>
</td>
<td style="width: 35.75px; height: 227px;">
<p>&nbsp;</p>
</td>
<td style="width: 237.4375px; height: 227px;">
<p><span style="font-size: 8pt;">You may have other rights as provided by law or regulation.</span></p>
<p><span style="font-size: 8pt;">Tu pudieras tener otros derechos que la ley o las regulaciones proveen.</span></p>
</td>
</tr>
</tbody>
</table>
<table style="margin-left: auto; margin-right: auto;">
<tbody>
<tr>
<td width="285">
<table width="100%">
<tbody>
<tr>
<td>
<p><span style="font-size: 8pt;">Client Signature: _______________________________</span></p>
</td>
</tr>
</tbody>
</table>
<span style="font-size: 8pt;">&nbsp;</span></td>
</tr>
</tbody>
</table>
<table style="margin-left: auto; margin-right: auto;">
<tbody>
<tr>
<td width="284">
<table width="100%">
<tbody>
<tr>
<td>
<p><span style="font-size: 8pt;">Date:&nbsp;&nbsp;&nbsp; ___/ ___/202_</span></p>
</td>
</tr>
</tbody>
</table>
<span style="font-size: 8pt;">&nbsp;</span></td>
</tr>
</tbody>
</table>
<p style="text-align: center;"><span style="font-size: 8pt;">How are you feeling today?</span></p>
<p style="text-align: center;"><span style="font-size: 8pt;">&iquest;C&oacute;mo te sientes hoy?</span></p>
<p style="text-align: center;">&nbsp;</p>
<table style="height: 1668px; margin-left: auto; margin-right: auto;" width="748">
<tbody>
<tr style="height: 46px;">
<td style="height: 46px; width: 44px;">
<p><span style="font-size: 8pt;">DAY</span></p>
</td>
<td style="height: 46px; width: 45.734375px;">
<p><span style="font-size: 8pt;">HAPPY</span></p>
</td>
<td style="height: 46px; width: 32.265625px;">
<p><span style="font-size: 8pt;">SAD</span></p>
</td>
<td style="height: 46px; width: 40.0625px;">
<p><span style="font-size: 8pt;">HURT</span></p>
</td>
<td style="height: 46px; width: 43.90625px;">
<p><span style="font-size: 8pt;">TIRED</span></p>
</td>
<td style="height: 46px; width: 62.3125px;">
<p><span style="font-size: 8pt;">EXCITED</span></p>
</td>
<td style="height: 46px; width: 50px;">
<p><span style="font-size: 8pt;">BORED</span></p>
</td>
<td style="height: 46px; width: 78.78125px;">
<p><span style="font-size: 8pt;">CONFUSED</span></p>
</td>
<td style="height: 46px; width: 69.46875px;">
<p><span style="font-size: 8pt;">NERVOUS</span></p>
</td>
<td style="height: 46px; width: 75.609375px;">
<p><span style="font-size: 8pt;">FRUSTRED</span></p>
</td>
<td style="height: 46px; width: 53.328125px;">
<p><span style="font-size: 8pt;">LONELY</span></p>
</td>
<td style="height: 46px; width: 35.578125px;">
<p><span style="font-size: 8pt;">SICK</span></p>
</td>
<td style="height: 46px; width: 35px;">
<p><span style="font-size: 8pt;">MAD</span></p>
</td>
</tr>
<tr style="height: 46px;">
<td style="height: 46px; width: 44px;">
<p><span style="font-size: 8pt;">1</span></p>
</td>
<td style="height: 46px; width: 45.734375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 32.265625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 40.0625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 43.90625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 62.3125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 50px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 78.78125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 69.46875px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 75.609375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 53.328125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35.578125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35px;">
<p>&nbsp;</p>
</td>
</tr>
<tr style="height: 46px;">
<td style="height: 46px; width: 44px;">
<p><span style="font-size: 8pt;">2</span></p>
</td>
<td style="height: 46px; width: 45.734375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 32.265625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 40.0625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 43.90625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 62.3125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 50px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 78.78125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 69.46875px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 75.609375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 53.328125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35.578125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35px;">
<p>&nbsp;</p>
</td>
</tr>
<tr style="height: 46px;">
<td style="height: 46px; width: 44px;">
<p><span style="font-size: 8pt;">3</span></p>
</td>
<td style="height: 46px; width: 45.734375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 32.265625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 40.0625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 43.90625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 62.3125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 50px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 78.78125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 69.46875px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 75.609375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 53.328125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35.578125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35px;">
<p>&nbsp;</p>
</td>
</tr>
<tr style="height: 46px;">
<td style="height: 46px; width: 44px;">
<p><span style="font-size: 8pt;">4</span></p>
</td>
<td style="height: 46px; width: 45.734375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 32.265625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 40.0625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 43.90625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 62.3125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 50px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 78.78125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 69.46875px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 75.609375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 53.328125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35.578125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35px;">
<p>&nbsp;</p>
</td>
</tr>
<tr style="height: 46px;">
<td style="height: 46px; width: 44px;">
<p><span style="font-size: 8pt;">5</span></p>
</td>
<td style="height: 46px; width: 45.734375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 32.265625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 40.0625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 43.90625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 62.3125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 50px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 78.78125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 69.46875px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 75.609375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 53.328125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35.578125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35px;">
<p>&nbsp;</p>
</td>
</tr>
<tr style="height: 46px;">
<td style="height: 46px; width: 44px;">
<p><span style="font-size: 8pt;">6</span></p>
</td>
<td style="height: 46px; width: 45.734375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 32.265625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 40.0625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 43.90625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 62.3125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 50px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 78.78125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 69.46875px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 75.609375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 53.328125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35.578125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35px;">
<p>&nbsp;</p>
</td>
</tr>
<tr style="height: 46px;">
<td style="height: 46px; width: 44px;">
<p><span style="font-size: 8pt;">7</span></p>
</td>
<td style="height: 46px; width: 45.734375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 32.265625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 40.0625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 43.90625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 62.3125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 50px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 78.78125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 69.46875px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 75.609375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 53.328125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35.578125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35px;">
<p>&nbsp;</p>
</td>
</tr>
<tr style="height: 46px;">
<td style="height: 46px; width: 44px;">
<p><span style="font-size: 8pt;">8</span></p>
</td>
<td style="height: 46px; width: 45.734375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 32.265625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 40.0625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 43.90625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 62.3125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 50px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 78.78125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 69.46875px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 75.609375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 53.328125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35.578125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35px;">
<p>&nbsp;</p>
</td>
</tr>
<tr style="height: 46px;">
<td style="height: 46px; width: 44px;">
<p><span style="font-size: 8pt;">9</span></p>
</td>
<td style="height: 46px; width: 45.734375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 32.265625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 40.0625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 43.90625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 62.3125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 50px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 78.78125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 69.46875px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 75.609375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 53.328125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35.578125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35px;">
<p>&nbsp;</p>
</td>
</tr>
<tr style="height: 46px;">
<td style="height: 46px; width: 44px;">
<p><span style="font-size: 8pt;">10</span></p>
</td>
<td style="height: 46px; width: 45.734375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 32.265625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 40.0625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 43.90625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 62.3125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 50px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 78.78125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 69.46875px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 75.609375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 53.328125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35.578125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35px;">
<p>&nbsp;</p>
</td>
</tr>
<tr style="height: 46px;">
<td style="height: 46px; width: 44px;">
<p><span style="font-size: 8pt;">11</span></p>
</td>
<td style="height: 46px; width: 45.734375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 32.265625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 40.0625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 43.90625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 62.3125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 50px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 78.78125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 69.46875px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 75.609375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 53.328125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35.578125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35px;">
<p>&nbsp;</p>
</td>
</tr>
<tr style="height: 46px;">
<td style="height: 46px; width: 44px;">
<p><span style="font-size: 8pt;">12</span></p>
</td>
<td style="height: 46px; width: 45.734375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 32.265625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 40.0625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 43.90625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 62.3125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 50px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 78.78125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 69.46875px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 75.609375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 53.328125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35.578125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35px;">
<p>&nbsp;</p>
</td>
</tr>
<tr style="height: 46px;">
<td style="height: 46px; width: 44px;">
<p><span style="font-size: 8pt;">13</span></p>
</td>
<td style="height: 46px; width: 45.734375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 32.265625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 40.0625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 43.90625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 62.3125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 50px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 78.78125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 69.46875px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 75.609375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 53.328125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35.578125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35px;">
<p>&nbsp;</p>
</td>
</tr>
<tr style="height: 46px;">
<td style="height: 46px; width: 44px;">
<p><span style="font-size: 8pt;">14</span></p>
</td>
<td style="height: 46px; width: 45.734375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 32.265625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 40.0625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 43.90625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 62.3125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 50px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 78.78125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 69.46875px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 75.609375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 53.328125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35.578125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35px;">
<p>&nbsp;</p>
</td>
</tr>
<tr style="height: 46px;">
<td style="height: 46px; width: 44px;">
<p><span style="font-size: 8pt;">15</span></p>
</td>
<td style="height: 46px; width: 45.734375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 32.265625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 40.0625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 43.90625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 62.3125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 50px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 78.78125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 69.46875px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 75.609375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 53.328125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35.578125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35px;">
<p>&nbsp;</p>
</td>
</tr>
<tr style="height: 46px;">
<td style="height: 46px; width: 44px;">
<p><span style="font-size: 8pt;">16</span></p>
</td>
<td style="height: 46px; width: 45.734375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 32.265625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 40.0625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 43.90625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 62.3125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 50px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 78.78125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 69.46875px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 75.609375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 53.328125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35.578125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35px;">
<p>&nbsp;</p>
</td>
</tr>
<tr style="height: 46px;">
<td style="height: 46px; width: 44px;">
<p><span style="font-size: 8pt;">17</span></p>
</td>
<td style="height: 46px; width: 45.734375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 32.265625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 40.0625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 43.90625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 62.3125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 50px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 78.78125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 69.46875px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 75.609375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 53.328125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35.578125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35px;">
<p>&nbsp;</p>
</td>
</tr>
<tr style="height: 46px;">
<td style="height: 46px; width: 44px;">
<p><span style="font-size: 8pt;">18</span></p>
</td>
<td style="height: 46px; width: 45.734375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 32.265625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 40.0625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 43.90625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 62.3125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 50px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 78.78125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 69.46875px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 75.609375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 53.328125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35.578125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35px;">
<p>&nbsp;</p>
</td>
</tr>
<tr style="height: 46px;">
<td style="height: 46px; width: 44px;">
<p><span style="font-size: 8pt;">19</span></p>
</td>
<td style="height: 46px; width: 45.734375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 32.265625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 40.0625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 43.90625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 62.3125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 50px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 78.78125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 69.46875px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 75.609375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 53.328125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35.578125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35px;">
<p>&nbsp;</p>
</td>
</tr>
<tr style="height: 46px;">
<td style="height: 46px; width: 44px;">
<p><span style="font-size: 8pt;">20</span></p>
</td>
<td style="height: 46px; width: 45.734375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 32.265625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 40.0625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 43.90625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 62.3125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 50px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 78.78125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 69.46875px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 75.609375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 53.328125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35.578125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35px;">
<p>&nbsp;</p>
</td>
</tr>
<tr style="height: 46px;">
<td style="height: 46px; width: 44px;">
<p><span style="font-size: 8pt;">21</span></p>
</td>
<td style="height: 46px; width: 45.734375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 32.265625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 40.0625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 43.90625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 62.3125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 50px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 78.78125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 69.46875px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 75.609375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 53.328125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35.578125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35px;">
<p>&nbsp;</p>
</td>
</tr>
<tr style="height: 46px;">
<td style="height: 46px; width: 44px;">
<p><span style="font-size: 8pt;">22</span></p>
</td>
<td style="height: 46px; width: 45.734375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 32.265625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 40.0625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 43.90625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 62.3125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 50px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 78.78125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 69.46875px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 75.609375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 53.328125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35.578125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35px;">
<p>&nbsp;</p>
</td>
</tr>
<tr style="height: 46px;">
<td style="height: 46px; width: 44px;">
<p><span style="font-size: 8pt;">23</span></p>
</td>
<td style="height: 46px; width: 45.734375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 32.265625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 40.0625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 43.90625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 62.3125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 50px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 78.78125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 69.46875px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 75.609375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 53.328125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35.578125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35px;">
<p>&nbsp;</p>
</td>
</tr>
<tr style="height: 46px;">
<td style="height: 46px; width: 44px;">
<p><span style="font-size: 8pt;">24</span></p>
</td>
<td style="height: 46px; width: 45.734375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 32.265625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 40.0625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 43.90625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 62.3125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 50px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 78.78125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 69.46875px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 75.609375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 53.328125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35.578125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35px;">
<p>&nbsp;</p>
</td>
</tr>
<tr style="height: 46px;">
<td style="height: 46px; width: 44px;">
<p><span style="font-size: 8pt;">25</span></p>
</td>
<td style="height: 46px; width: 45.734375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 32.265625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 40.0625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 43.90625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 62.3125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 50px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 78.78125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 69.46875px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 75.609375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 53.328125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35.578125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35px;">
<p>&nbsp;</p>
</td>
</tr>
<tr style="height: 46px;">
<td style="height: 46px; width: 44px;">
<p><span style="font-size: 8pt;">26</span></p>
</td>
<td style="height: 46px; width: 45.734375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 32.265625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 40.0625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 43.90625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 62.3125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 50px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 78.78125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 69.46875px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 75.609375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 53.328125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35.578125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35px;">
<p>&nbsp;</p>
</td>
</tr>
<tr style="height: 46px;">
<td style="height: 46px; width: 44px;">
<p><span style="font-size: 8pt;">27</span></p>
</td>
<td style="height: 46px; width: 45.734375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 32.265625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 40.0625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 43.90625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 62.3125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 50px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 78.78125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 69.46875px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 75.609375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 53.328125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35.578125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35px;">
<p>&nbsp;</p>
</td>
</tr>
<tr style="height: 46px;">
<td style="height: 46px; width: 44px;">
<p><span style="font-size: 8pt;">28</span></p>
</td>
<td style="height: 46px; width: 45.734375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 32.265625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 40.0625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 43.90625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 62.3125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 50px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 78.78125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 69.46875px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 75.609375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 53.328125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35.578125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35px;">
<p>&nbsp;</p>
</td>
</tr>
<tr style="height: 46px;">
<td style="height: 46px; width: 44px;">
<p><span style="font-size: 8pt;">29</span></p>
</td>
<td style="height: 46px; width: 45.734375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 32.265625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 40.0625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 43.90625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 62.3125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 50px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 78.78125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 69.46875px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 75.609375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 53.328125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35.578125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35px;">
<p>&nbsp;</p>
</td>
</tr>
<tr style="height: 46px;">
<td style="height: 46px; width: 44px;">
<p><span style="font-size: 8pt;">30</span></p>
</td>
<td style="height: 46px; width: 45.734375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 32.265625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 40.0625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 43.90625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 62.3125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 50px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 78.78125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 69.46875px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 75.609375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 53.328125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35.578125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35px;">
<p>&nbsp;</p>
</td>
</tr>
<tr style="height: 46px;">
<td style="height: 46px; width: 44px;">
<p><span style="font-size: 8pt;">31</span></p>
</td>
<td style="height: 46px; width: 45.734375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 32.265625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 40.0625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 43.90625px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 62.3125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 50px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 78.78125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 69.46875px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 75.609375px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 53.328125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35.578125px;">
<p>&nbsp;</p>
</td>
<td style="height: 46px; width: 35px;">
<p>&nbsp;</p>
</td>
</tr>
</tbody>
</table>
<p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;"><span style="font-size: 8pt;">Client Name: _________________________&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Date: ____/_____/202__</span></p>
<p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;"><span style="font-size: 8pt;">RESEMBLES HOW MUCH PAIN YOU FEEL RIGHT NOW?</span></p>
<p style="text-align: center;"><span style="font-size: 8pt;">&iquest;ALGUNA CARITA SE PARECE A CU&Aacute;NTO DOLOR SIENTES AHORA MISMO?</span></p>
<p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;">&nbsp;</p>
<table style="margin-left: auto; margin-right: auto;">
<tbody>
<tr>
<td width="55">
<p><span style="font-size: 8pt;">DAY</span></p>
</td>
<td width="57">
<p><span style="font-size: 8pt;">PAIN FREE</span></p>
</td>
<td width="42">
<p><span style="font-size: 8pt;">VERY MILD</span></p>
</td>
<td width="42">
<p><span style="font-size: 8pt;">DISCOM-FORTING</span></p>
</td>
<td width="43">
<p><span style="font-size: 8pt;">TOLERABLE</span></p>
</td>
<td width="49">
<p><span style="font-size: 8pt;">DISTRESSING</span></p>
</td>
<td width="49">
<p><span style="font-size: 8pt;">VERY</span></p>
<p><span style="font-size: 8pt;">DISTRESSING</span></p>
</td>
<td width="46">
<p><span style="font-size: 8pt;">INTENSE</span></p>
</td>
<td width="48">
<p><span style="font-size: 8pt;">VERY</span></p>
<p><span style="font-size: 8pt;">INTENSE</span></p>
</td>
<td width="48">
<p><span style="font-size: 8pt;">UTTERLY</span></p>
<p><span style="font-size: 8pt;">HORRIBLE</span></p>
</td>
<td width="60">
<p><span style="font-size: 8pt;">EXCRUCIATING</span></p>
<p><span style="font-size: 8pt;">UNBEARABLE</span></p>
</td>
<td width="60">
<p><span style="font-size: 8pt;">UNIMAGINABLE</span></p>
<p><span style="font-size: 8pt;">UNSPEAKABLE &nbsp;</span></p>
</td>
</tr>
<tr>
<td width="55">
<p>&nbsp;</p>
</td>
<td width="57">
<p><span style="font-size: 8pt;"><strong>NO PAIN</strong></span></p>
</td>
<td colspan="3" width="127">
<p><span style="font-size: 8pt;"><strong>MINOR PAIN</strong></span></p>
</td>
<td colspan="3" width="144">
<p><span style="font-size: 8pt;"><strong>MODERATE PAIN</strong></span></p>
</td>
<td colspan="4" width="216">
<p><span style="font-size: 8pt;"><strong>SEVERE PAIN</strong></span></p>
</td>
</tr>
<tr>
<td width="55">
<p><span style="font-size: 8pt;">1</span></p>
</td>
<td width="57">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="127">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="144">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="4" width="216">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
</tr>
<tr>
<td width="55">
<p><span style="font-size: 8pt;">2</span></p>
</td>
<td width="57">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="127">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="144">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="4" width="216">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
</tr>
<tr>
<td width="55">
<p><span style="font-size: 8pt;">3</span></p>
</td>
<td width="57">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="127">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="144">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="4" width="216">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
</tr>
<tr>
<td width="55">
<p><span style="font-size: 8pt;">4</span></p>
</td>
<td width="57">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="127">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="144">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="4" width="216">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
</tr>
<tr>
<td width="55">
<p><span style="font-size: 8pt;">5</span></p>
</td>
<td width="57">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="127">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="144">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="4" width="216">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
</tr>
<tr>
<td width="55">
<p><span style="font-size: 8pt;">6</span></p>
</td>
<td width="57">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="127">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="144">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="4" width="216">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
</tr>
<tr>
<td width="55">
<p><span style="font-size: 8pt;">7</span></p>
</td>
<td width="57">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="127">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="144">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="4" width="216">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
</tr>
<tr>
<td width="55">
<p><span style="font-size: 8pt;">8</span></p>
</td>
<td width="57">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="127">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="144">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="4" width="216">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
</tr>
<tr>
<td width="55">
<p><span style="font-size: 8pt;">9</span></p>
</td>
<td width="57">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="127">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="144">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="4" width="216">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
</tr>
<tr>
<td width="55">
<p><span style="font-size: 8pt;">10</span></p>
</td>
<td width="57">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="127">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="144">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="4" width="216">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
</tr>
<tr>
<td width="55">
<p><span style="font-size: 8pt;">11</span></p>
</td>
<td width="57">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="127">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="144">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="4" width="216">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
</tr>
<tr>
<td width="55">
<p><span style="font-size: 8pt;">12</span></p>
</td>
<td width="57">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="127">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="144">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="4" width="216">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
</tr>
<tr>
<td width="55">
<p><span style="font-size: 8pt;">13</span></p>
</td>
<td width="57">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="127">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="144">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="4" width="216">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
</tr>
<tr>
<td width="55">
<p><span style="font-size: 8pt;">14</span></p>
</td>
<td width="57">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="127">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="144">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="4" width="216">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
</tr>
<tr>
<td width="55">
<p><span style="font-size: 8pt;">15</span></p>
</td>
<td width="57">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="127">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="144">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="4" width="216">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
</tr>
<tr>
<td width="55">
<p><span style="font-size: 8pt;">16</span></p>
</td>
<td width="57">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="127">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="144">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="4" width="216">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
</tr>
<tr>
<td width="55">
<p><span style="font-size: 8pt;">17</span></p>
</td>
<td width="57">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="127">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="144">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="4" width="216">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
</tr>
<tr>
<td width="55">
<p><span style="font-size: 8pt;">18</span></p>
</td>
<td width="57">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="127">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="144">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="4" width="216">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
</tr>
<tr>
<td width="55">
<p><span style="font-size: 8pt;">19</span></p>
</td>
<td width="57">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="127">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="144">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="4" width="216">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
</tr>
<tr>
<td width="55">
<p><span style="font-size: 8pt;">20</span></p>
</td>
<td width="57">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="127">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="144">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="4" width="216">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
</tr>
<tr>
<td width="55">
<p><span style="font-size: 8pt;">21</span></p>
</td>
<td width="57">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="127">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="144">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="4" width="216">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
</tr>
<tr>
<td width="55">
<p><span style="font-size: 8pt;">22</span></p>
</td>
<td width="57">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="127">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="144">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="4" width="216">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
</tr>
<tr>
<td width="55">
<p><span style="font-size: 8pt;">23</span></p>
</td>
<td width="57">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="127">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="144">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="4" width="216">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
</tr>
<tr>
<td width="55">
<p><span style="font-size: 8pt;">24</span></p>
</td>
<td width="57">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="127">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="144">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="4" width="216">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
</tr>
<tr>
<td width="55">
<p><span style="font-size: 8pt;">25</span></p>
</td>
<td width="57">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="127">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="144">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="4" width="216">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
</tr>
<tr>
<td width="55">
<p><span style="font-size: 8pt;">26</span></p>
</td>
<td width="57">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="127">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="144">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="4" width="216">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
</tr>
<tr>
<td width="55">
<p><span style="font-size: 8pt;">27</span></p>
</td>
<td width="57">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="127">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="144">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="4" width="216">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
</tr>
<tr>
<td width="55">
<p><span style="font-size: 8pt;">28</span></p>
</td>
<td width="57">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="127">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="144">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="4" width="216">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
</tr>
<tr>
<td width="55">
<p><span style="font-size: 8pt;">29</span></p>
</td>
<td width="57">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="127">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="144">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="4" width="216">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
</tr>
<tr>
<td width="55">
<p><span style="font-size: 8pt;">30</span></p>
</td>
<td width="57">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="127">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="144">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="4" width="216">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
</tr>
<tr>
<td width="55">
<p><span style="font-size: 8pt;">31</span></p>
</td>
<td width="57">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="127">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="3" width="144">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
<td colspan="4" width="216">
<p><span style="font-size: 8pt;">o&nbsp; &nbsp;</span></p>
</td>
</tr>
</tbody>
</table>
<p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;"><span style="font-size: 8pt;">Client Name: _________________________&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Date: ____/_____/202__</span></p>
            </body>
        </html>
        