
        <!DOCTYPE html>
        <html lang="es">
            <head>
                <meta charset="utf-8">
                <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
                <meta name="viewport" content="width=device-width, initial-scale=1">
                
                <title>Clothing And Identification</title>
            </head>
            <body style="margin-top: -25px !important;">
        <p style="text-align: center;"><span style="font-size: 14pt; font-family: 'book antiqua', palatino, serif;">Proper clothing and identification</span><br /><span style="font-family: 'book antiqua', palatino, serif; font-size: 8pt;">Vestimenta y Identificaci&oacute;n apropiada</span><br /><span style="font-family: 'book antiqua', palatino, serif; font-size: 12pt;">Evaluation and training for staff</span><br /><span style="font-family: 'book antiqua', palatino, serif; font-size: 8pt;">Evaluaci&oacute;n y formaci&oacute;n del personal</span></p>
<p style="text-align: center;"><img src="/home/unitedfamilyhc/public_html/app/public/filesUsers/Clothing_Identification.jpeg" alt="" width="285" height="400" /></p>
<p style="text-align: left;"><span style="font-family: 'book antiqua', palatino, serif;">All work deserves its distinguished dress for good morals and easy identification.</span><br /><span style="font-family: 'book antiqua', palatino, serif; font-size: 8pt;">Todo trabajo merece su vestimenta distinguida por buena moral y f&aacute;cil identificaci&oacute;n</span><br /><span style="font-family: 'book antiqua', palatino, serif;">With good clothing our patients feel the confidence of professionalism.</span><br /><span style="font-family: 'book antiqua', palatino, serif; font-size: 8pt;">Con una buena vestimenta nuestros pacientes sienten la confianza del profesionalismo.</span><br /><span style="font-family: 'book antiqua', palatino, serif;">With a visible identification the staff is protected against possible misunderstandings.</span><br /><span style="font-family: 'book antiqua', palatino, serif; font-size: 8pt;">Con una identificaci&oacute;n visible el staff esta protegido contra posibles malos entendidos.</span><br /><span style="font-family: 'book antiqua', palatino, serif;">The respect we show our patients is the best way to start changing the lives of the little angels who need our care and protection.</span><br /><span style="font-family: 'book antiqua', palatino, serif; font-size: 8pt;">El respeto que mostramos a nuestros pacientes es la mejor manera de empezar a cambiar la vida de los angelitos que necesitan nuestra atenci&oacute;n y protecci&oacute;n.</span></p>
<p><span style="font-family: 'book antiqua', palatino, serif;">I agree with the dress policies:</span></p>
<p><span style="font-family: 'book antiqua', palatino, serif;">Name: {{ $worker->first_name }} {{ $worker->last_name }} / Staff name initials: ______</span></p>
            </body>
        </html>
        