<!DOCTYPE html>
<html>
<head>
	<title>Generate Laravel TCPDF by codeanddeploy.com</title>
</head>
<body>
	<h1 style="color:red;">{!! $title !!}</h1>

	<br>

	<p>Your message here.</p>
</body>
</html>